(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (self["webpackChunkles_sagas_mp3"] = self["webpackChunkles_sagas_mp3"] || []).push([["main"], {
    /***/
    98255:
    /*!*******************************************************!*\
      !*** ./$_lazy_route_resources/ lazy namespace object ***!
      \*******************************************************/

    /***/
    function _(module) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = 98255;
      module.exports = webpackEmptyAsyncContext;
      /***/
    },

    /***/
    90158:
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "AppRoutingModule": function AppRoutingModule() {
          return (
            /* binding */
            _AppRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      71258);

      var routes = [{
        path: '',
        redirectTo: 'news',
        pathMatch: 'full'
      }, {
        path: 'sagas',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() */
          [__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_sagas_list-sagas_list-sagas_module_ts")]).then(__webpack_require__.bind(__webpack_require__,
          /*! ./pages/sagas/list-sagas/list-sagas.module */
          56491)).then(function (m) {
            return m.ListSagasPageModule;
          });
        }
      }, {
        path: 'sagas/:id',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() */
          [__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_sagas_view-saga_view-saga_module_ts")]).then(__webpack_require__.bind(__webpack_require__,
          /*! ./pages/sagas/view-saga/view-saga.module */
          64812)).then(function (m) {
            return m.ViewSagaPageModule;
          });
        }
      }, {
        path: 'news',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() */
          "src_app_pages_news_list-news_list-news_module_ts").then(__webpack_require__.bind(__webpack_require__,
          /*! ./pages/news/list-news/list-news.module */
          27654)).then(function (m) {
            return m.ListNewsPageModule;
          });
        }
      }, {
        path: 'news/:id',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() */
          [__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_news_view-news_view-news_module_ts")]).then(__webpack_require__.bind(__webpack_require__,
          /*! ./pages/news/view-news/view-news.module */
          7607)).then(function (m) {
            return m.ViewNewsPageModule;
          });
        }
      }, {
        path: 'login',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() */
          "src_app_pages_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__,
          /*! ./pages/login/login.module */
          21053)).then(function (m) {
            return m.LoginPageModule;
          });
        }
      }, {
        path: 'signup',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() */
          "src_app_pages_signup_signup_module_ts").then(__webpack_require__.bind(__webpack_require__,
          /*! ./pages/signup/signup.module */
          17110)).then(function (m) {
            return m.SignupPageModule;
          });
        }
      }, {
        path: 'sync',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() */
          [__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_admin_sync_sync_module_ts")]).then(__webpack_require__.bind(__webpack_require__,
          /*! ./pages/admin/sync/sync.module */
          26714)).then(function (m) {
            return m.SyncPageModule;
          });
        }
      }];

      var _AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };

      _AppRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, {
          preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules,
          relativeLinkResolution: 'legacy'
        })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
      })], _AppRoutingModule);
      /***/
    },

    /***/
    55041:
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "AppComponent": function AppComponent() {
          return (
            /* binding */
            _AppComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./app.component.html */
      75158);
      /* harmony import */


      var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./app.component.scss */
      53040);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      7602);
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      64967);
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      73588);
      /* harmony import */


      var _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./services/auth/auth.service */
      51228);
      /* harmony import */


      var _services_fcm_fcm_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./services/fcm/fcm.service */
      72265);

      var _AppComponent = /*#__PURE__*/function () {
        function AppComponent(platform, splashScreen, statusBar, fcmService, navCtrl, authService) {
          _classCallCheck(this, AppComponent);

          this.platform = platform;
          this.splashScreen = splashScreen;
          this.statusBar = statusBar;
          this.fcmService = fcmService;
          this.navCtrl = navCtrl;
          this.authService = authService;
          this.appPages = [{
            title: 'Actualités',
            url: '/news',
            icon: 'newspaper'
          }, {
            title: 'Liste des Sagas',
            url: '/sagas',
            icon: 'list'
          }];
          this.initializeApp();
        }

        _createClass(AppComponent, [{
          key: "initializeApp",
          value: function initializeApp() {
            var _this = this;

            this.platform.ready().then(function () {
              _this.statusBar.styleDefault();

              _this.splashScreen.hide();

              _this.fcmService.initPush();
            });
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            this.authService.whoami();
          }
        }, {
          key: "logout",
          value: function logout() {
            localStorage.setItem('jwt', null);
            this.authService.currentTokenValue = null;
            localStorage.setItem('user', null);
            this.authService.currentUserValue = null;
            this.navCtrl.navigateRoot('/news');
          }
        }]);

        return AppComponent;
      }();

      _AppComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform
        }, {
          type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__.SplashScreen
        }, {
          type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__.StatusBar
        }, {
          type: _services_fcm_fcm_service__WEBPACK_IMPORTED_MODULE_5__.FcmService
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController
        }, {
          type: _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService
        }];
      };

      _AppComponent = (0, tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-root',
        template: _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_app_component_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__]
      })], _AppComponent);
      /***/
    },

    /***/
    36747:
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "AppModule": function AppModule() {
          return (
            /* binding */
            _AppModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/platform-browser */
      71570);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! @angular/router */
      71258);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/common/http */
      53882);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/forms */
      1707);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @ionic/angular */
      7602);
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      64967);
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      73588);
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app.component */
      55041);
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./app-routing.module */
      90158);
      /* harmony import */


      var _interceptors_jwt_interceptor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./interceptors/jwt.interceptor */
      53543);
      /* harmony import */


      var _services_categories_category_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./services/categories/category.service */
      16471);
      /* harmony import */


      var _services_rss_message_rss_message_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./services/rss.message/rss.message.service */
      36232);
      /* harmony import */


      var _services_sagas_saga_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./services/sagas/saga.service */
      24041);
      /* harmony import */


      var _services_config_config_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./services/config/config.service */
      88939);

      var appConfig = function appConfig(config) {
        return function () {
          return config.loadConfig();
        };
      };

      var _AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };

      _AppModule = (0, tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_10__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_3__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_13__.HttpClientModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.ReactiveFormsModule],
        providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_1__.StatusBar, _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_0__.SplashScreen, {
          provide: _angular_router__WEBPACK_IMPORTED_MODULE_15__.RouteReuseStrategy,
          useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicRouteStrategy
        }, {
          provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_13__.HTTP_INTERCEPTORS,
          useClass: _interceptors_jwt_interceptor__WEBPACK_IMPORTED_MODULE_4__.JwtInterceptor,
          multi: true
        }, _services_categories_category_service__WEBPACK_IMPORTED_MODULE_5__.CategoryService, _services_rss_message_rss_message_service__WEBPACK_IMPORTED_MODULE_6__.RssMessageService, _services_sagas_saga_service__WEBPACK_IMPORTED_MODULE_7__.SagaService, _services_config_config_service__WEBPACK_IMPORTED_MODULE_8__.ConfigService, {
          provide: _angular_core__WEBPACK_IMPORTED_MODULE_10__.APP_INITIALIZER,
          useFactory: appConfig,
          multi: true,
          deps: [_services_config_config_service__WEBPACK_IMPORTED_MODULE_8__.ConfigService]
        }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent]
      })], _AppModule);
      /***/
    },

    /***/
    53543:
    /*!*************************************************!*\
      !*** ./src/app/interceptors/jwt.interceptor.ts ***!
      \*************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "JwtInterceptor": function JwtInterceptor() {
          return (
            /* binding */
            _JwtInterceptor
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../services/auth/auth.service */
      51228);

      var _JwtInterceptor = /*#__PURE__*/function () {
        function JwtInterceptor(authService) {
          _classCallCheck(this, JwtInterceptor);

          this.authService = authService;
        }

        _createClass(JwtInterceptor, [{
          key: "intercept",
          value: function intercept(request, next) {
            var jwtResponse = this.authService.currentTokenValue;

            if (jwtResponse && jwtResponse.token) {
              request = request.clone({
                setHeaders: {
                  Authorization: "Bearer ".concat(jwtResponse.token)
                }
              });
            }

            return next.handle(request);
          }
        }]);

        return JwtInterceptor;
      }();

      _JwtInterceptor.ctorParameters = function () {
        return [{
          type: _services_auth_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService
        }];
      };

      _JwtInterceptor = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)()], _JwtInterceptor);
      /***/
    },

    /***/
    83836:
    /*!******************************************************!*\
      !*** ./src/app/models/security/jwt.request.model.ts ***!
      \******************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "JwtRequestModel": function JwtRequestModel() {
          return (
            /* binding */
            _JwtRequestModel
          );
        }
        /* harmony export */

      });

      var _JwtRequestModel = function _JwtRequestModel() {
        _classCallCheck(this, _JwtRequestModel);

        this.email = '';
        this.password = '';
      };
      /***/

    },

    /***/
    84872:
    /*!**************************************!*\
      !*** ./src/app/models/user.model.ts ***!
      \**************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "UserModel": function UserModel() {
          return (
            /* binding */
            _UserModel
          );
        }
        /* harmony export */

      });

      var _UserModel = function _UserModel() {
        _classCallCheck(this, _UserModel);

        this.username = '';
        this.password = '';
        this.email = '';
        this.enabled = false;
        this.lastPasswordResetDate = new Date();
      };
      /***/

    },

    /***/
    51228:
    /*!***********************************************!*\
      !*** ./src/app/services/auth/auth.service.ts ***!
      \***********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "AuthService": function AuthService() {
          return (
            /* binding */
            _AuthService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common/http */
      53882);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs */
      76491);
      /* harmony import */


      var src_app_models_security_jwt_request_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! src/app/models/security/jwt.request.model */
      83836);
      /* harmony import */


      var src_app_models_user_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! src/app/models/user.model */
      84872);
      /* harmony import */


      var _config_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../config/config.service */
      88939);

      var _AuthService = /*#__PURE__*/function () {
        function AuthService(http, configService) {
          _classCallCheck(this, AuthService);

          this.http = http;
          this.configService = configService;
          this.currentTokenSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject(JSON.parse(localStorage.getItem('jwt')));
          this.currentUserSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject(JSON.parse(localStorage.getItem('user')));
        }

        _createClass(AuthService, [{
          key: "currentTokenValue",
          get: function get() {
            return this.currentTokenSubject.value;
          },
          set: function set(jwtResponse) {
            this.currentTokenSubject.next(jwtResponse);
          }
        }, {
          key: "currentUserValue",
          get: function get() {
            var user = this.currentUserSubject.value;

            if (user == null) {
              return new src_app_models_user_model__WEBPACK_IMPORTED_MODULE_1__.UserModel();
            }

            return this.currentUserSubject.value;
          },
          set: function set(user) {
            this.currentUserSubject.next(user);
          }
        }, {
          key: "signup",
          value: function signup(email, password) {
            var jwtRequest = new src_app_models_security_jwt_request_model__WEBPACK_IMPORTED_MODULE_0__.JwtRequestModel();
            jwtRequest.email = email;
            jwtRequest.password = password;
            return this.http.post("".concat(this.configService.get('apiUrl'), "/auth/signup"), jwtRequest);
          }
        }, {
          key: "login",
          value: function login(email, password) {
            var jwtRequest = new src_app_models_security_jwt_request_model__WEBPACK_IMPORTED_MODULE_0__.JwtRequestModel();
            jwtRequest.email = email;
            jwtRequest.password = password;
            return this.http.post("".concat(this.configService.get('apiUrl'), "/auth/login"), jwtRequest);
          }
        }, {
          key: "whoami",
          value: function whoami() {
            var _this2 = this;

            if (this.currentTokenValue != null) {
              this.http.get("".concat(this.configService.get('apiUrl'), "/auth/whoami")).subscribe(function (res) {
                localStorage.setItem('user', JSON.stringify(res));

                _this2.currentUserSubject.next(res);
              });
            }
          }
        }]);

        return AuthService;
      }();

      _AuthService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient
        }, {
          type: _config_config_service__WEBPACK_IMPORTED_MODULE_2__.ConfigService
        }];
      };

      _AuthService = (0, tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
      })], _AuthService);
      /***/
    },

    /***/
    16471:
    /*!*********************************************************!*\
      !*** ./src/app/services/categories/category.service.ts ***!
      \*********************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "CategoryService": function CategoryService() {
          return (
            /* binding */
            _CategoryService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      53882);
      /* harmony import */


      var _config_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../config/config.service */
      88939);

      var _CategoryService = /*#__PURE__*/function () {
        function CategoryService(http, configService) {
          _classCallCheck(this, CategoryService);

          this.http = http;
          this.configService = configService;
        }

        _createClass(CategoryService, [{
          key: "getAll",
          value: function getAll() {
            return this.http.get("".concat(this.configService.get('apiUrl'), "/categories"));
          }
        }, {
          key: "getAllByIds",
          value: function getAllByIds(ids) {
            var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams().set('ids', ids.toString());
            return this.http.get("".concat(this.configService.get('apiUrl'), "/categories"), {
              params: params
            });
          }
        }]);

        return CategoryService;
      }();

      _CategoryService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
        }, {
          type: _config_config_service__WEBPACK_IMPORTED_MODULE_0__.ConfigService
        }];
      };

      _CategoryService = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
      })], _CategoryService);
      /***/
    },

    /***/
    88939:
    /*!***************************************************!*\
      !*** ./src/app/services/config/config.service.ts ***!
      \***************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ConfigService": function ConfigService() {
          return (
            /* binding */
            _ConfigService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/common/http */
      53882);

      var _ConfigService = /*#__PURE__*/function () {
        function ConfigService(_http) {
          _classCallCheck(this, ConfigService);

          this._http = _http;
          this.apiUrl = '';
        }

        _createClass(ConfigService, [{
          key: "loadConfig",
          value: function loadConfig() {
            var _this3 = this;

            return this._http.get('./assets/config.json').toPromise().then(function (res) {
              _this3.appConfig = res;
            });
          }
        }, {
          key: "get",
          value: function get(key) {
            return this.appConfig[key];
          }
        }]);

        return ConfigService;
      }();

      _ConfigService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpClient
        }];
      };

      _ConfigService = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
      })], _ConfigService);
      /***/
    },

    /***/
    72265:
    /*!*********************************************!*\
      !*** ./src/app/services/fcm/fcm.service.ts ***!
      \*********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "FcmService": function FcmService() {
          return (
            /* binding */
            _FcmService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @capacitor/core */
      41899);
      /* harmony import */


      var _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @capacitor/push-notifications */
      62351);

      var _FcmService = /*#__PURE__*/function () {
        function FcmService() {
          _classCallCheck(this, FcmService);
        }

        _createClass(FcmService, [{
          key: "initPush",
          value: function initPush() {
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.Capacitor.getPlatform() !== 'web') {
              this.initFCM();
            }
          }
        }, {
          key: "initFCM",
          value: function initFCM() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_1__.PushNotifications.register();

                    case 2:
                      // On success, we should be able to receive notifications
                      _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_1__.PushNotifications.addListener('registration', function (token) {
                        console.log('Push registration success, token: ' + token.value);
                      }); // Some issue with our setup and push will not work


                      _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_1__.PushNotifications.addListener('registrationError', function (error) {
                        console.log('Error on registration: ' + JSON.stringify(error));
                      }); // Show us the notification payload if the app is open on our device


                      _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_1__.PushNotifications.addListener('pushNotificationReceived', function (notification) {
                        console.log('Push received: ' + JSON.stringify(notification));
                      }); // Method called when tapping on a notification


                      _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_1__.PushNotifications.addListener('pushNotificationActionPerformed', function (notification) {
                        console.log('Push action performed: ' + JSON.stringify(notification));
                      });

                    case 6:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee);
            }));
          }
        }]);

        return FcmService;
      }();

      _FcmService.ctorParameters = function () {
        return [];
      };

      _FcmService = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
      })], _FcmService);
      /***/
    },

    /***/
    36232:
    /*!*************************************************************!*\
      !*** ./src/app/services/rss.message/rss.message.service.ts ***!
      \*************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RssMessageService": function RssMessageService() {
          return (
            /* binding */
            _RssMessageService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      53882);
      /* harmony import */


      var _config_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../config/config.service */
      88939);

      var _RssMessageService = /*#__PURE__*/function () {
        function RssMessageService(http, configService) {
          _classCallCheck(this, RssMessageService);

          this.http = http;
          this.configService = configService;
        }

        _createClass(RssMessageService, [{
          key: "getByFeedTitle",
          value: function getByFeedTitle(feedTitle) {
            return this.http.get("".concat(this.configService.get('apiUrl'), "/rss?feedTitle=").concat(feedTitle));
          }
        }, {
          key: "getById",
          value: function getById(id) {
            return this.http.get("".concat(this.configService.get('apiUrl'), "/rss/").concat(id));
          }
        }]);

        return RssMessageService;
      }();

      _RssMessageService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
        }, {
          type: _config_config_service__WEBPACK_IMPORTED_MODULE_0__.ConfigService
        }];
      };

      _RssMessageService = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
      })], _RssMessageService);
      /***/
    },

    /***/
    24041:
    /*!************************************************!*\
      !*** ./src/app/services/sagas/saga.service.ts ***!
      \************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SagaService": function SagaService() {
          return (
            /* binding */
            _SagaService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      53882);
      /* harmony import */


      var _config_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../config/config.service */
      88939);

      var _SagaService = /*#__PURE__*/function () {
        function SagaService(http, configService) {
          _classCallCheck(this, SagaService);

          this.http = http;
          this.configService = configService;
        }

        _createClass(SagaService, [{
          key: "getAll",
          value: function getAll() {
            return this.http.get("".concat(this.configService.get('apiUrl'), "/saga"));
          }
        }, {
          key: "getById",
          value: function getById(id) {
            return this.http.get("".concat(this.configService.get('apiUrl'), "/saga/").concat(id));
          }
        }, {
          key: "getPaginated",
          value: function getPaginated(offset, limit) {
            var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams().set('offset', offset.toString()).set('limit', limit.toString());
            return this.http.get("".concat(this.configService.get('apiUrl'), "/saga"), {
              params: params
            });
          }
        }, {
          key: "search",
          value: function search(_search) {
            return this.http.get("".concat(this.configService.get('apiUrl'), "/saga?search=").concat(_search));
          }
        }]);

        return SagaService;
      }();

      _SagaService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
        }, {
          type: _config_config_service__WEBPACK_IMPORTED_MODULE_0__.ConfigService
        }];
      };

      _SagaService = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
      })], _SagaService);
      /***/
    },

    /***/
    92340:
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "environment": function environment() {
          return (
            /* binding */
            _environment
          );
        }
        /* harmony export */

      }); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var _environment = {
        production: false,
        webUrl: 'http://localhost:8100',
        apiUrl: 'http://localhost:8080/api'
      };
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/plugins/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    14431:
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/platform-browser-dynamic */
      61882);
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./app/app.module */
      36747);
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./environments/environment */
      92340);

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
        (0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
      }

      (0, _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)["catch"](function (err) {
        return console.log(err);
      });
      /***/
    },

    /***/
    50863:
    /*!******************************************************************************************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
      \******************************************************************************************************************************************/

    /***/
    function _(module, __unused_webpack_exports, __webpack_require__) {
      var map = {
        "./ion-action-sheet.entry.js": [90733, "common", "node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"],
        "./ion-alert.entry.js": [20985, "common", "node_modules_ionic_core_dist_esm_ion-alert_entry_js"],
        "./ion-app_8.entry.js": [93899, "common", "node_modules_ionic_core_dist_esm_ion-app_8_entry_js"],
        "./ion-avatar_3.entry.js": [5121, "common", "node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"],
        "./ion-back-button.entry.js": [52960, "common", "node_modules_ionic_core_dist_esm_ion-back-button_entry_js"],
        "./ion-backdrop.entry.js": [45473, "node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"],
        "./ion-button_2.entry.js": [19787, "common", "node_modules_ionic_core_dist_esm_ion-button_2_entry_js"],
        "./ion-card_5.entry.js": [66165, "common", "node_modules_ionic_core_dist_esm_ion-card_5_entry_js"],
        "./ion-checkbox.entry.js": [69569, "common", "node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"],
        "./ion-chip.entry.js": [35119, "common", "node_modules_ionic_core_dist_esm_ion-chip_entry_js"],
        "./ion-col_3.entry.js": [90799, "node_modules_ionic_core_dist_esm_ion-col_3_entry_js"],
        "./ion-datetime_3.entry.js": [68918, "common", "node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"],
        "./ion-fab_3.entry.js": [94028, "common", "node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"],
        "./ion-img.entry.js": [98107, "node_modules_ionic_core_dist_esm_ion-img_entry_js"],
        "./ion-infinite-scroll_2.entry.js": [72178, "node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"],
        "./ion-input.entry.js": [20123, "common", "node_modules_ionic_core_dist_esm_ion-input_entry_js"],
        "./ion-item-option_3.entry.js": [18706, "common", "node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"],
        "./ion-item_8.entry.js": [12099, "common", "node_modules_ionic_core_dist_esm_ion-item_8_entry_js"],
        "./ion-loading.entry.js": [84868, "common", "node_modules_ionic_core_dist_esm_ion-loading_entry_js"],
        "./ion-menu_3.entry.js": [54377, "common", "node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"],
        "./ion-modal.entry.js": [15678, "common", "node_modules_ionic_core_dist_esm_ion-modal_entry_js"],
        "./ion-nav_2.entry.js": [16735, "common", "node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"],
        "./ion-popover.entry.js": [87686, "common", "node_modules_ionic_core_dist_esm_ion-popover_entry_js"],
        "./ion-progress-bar.entry.js": [48555, "common", "node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"],
        "./ion-radio_2.entry.js": [30568, "common", "node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"],
        "./ion-range.entry.js": [6231, "common", "node_modules_ionic_core_dist_esm_ion-range_entry_js"],
        "./ion-refresher_2.entry.js": [45772, "common", "node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"],
        "./ion-reorder_2.entry.js": [14977, "common", "node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"],
        "./ion-ripple-effect.entry.js": [42886, "node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"],
        "./ion-route_4.entry.js": [54990, "common", "node_modules_ionic_core_dist_esm_ion-route_4_entry_js"],
        "./ion-searchbar.entry.js": [13810, "common", "node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"],
        "./ion-segment_2.entry.js": [2446, "common", "node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"],
        "./ion-select_3.entry.js": [47619, "common", "node_modules_ionic_core_dist_esm_ion-select_3_entry_js"],
        "./ion-slide_2.entry.js": [28393, "node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"],
        "./ion-spinner.entry.js": [56281, "common", "node_modules_ionic_core_dist_esm_ion-spinner_entry_js"],
        "./ion-split-pane.entry.js": [35932, "node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"],
        "./ion-tab-bar_2.entry.js": [57970, "common", "node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"],
        "./ion-tab_2.entry.js": [80298, "common", "node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"],
        "./ion-text.entry.js": [71006, "common", "node_modules_ionic_core_dist_esm_ion-text_entry_js"],
        "./ion-textarea.entry.js": [74783, "common", "node_modules_ionic_core_dist_esm_ion-textarea_entry_js"],
        "./ion-toast.entry.js": [62749, "common", "node_modules_ionic_core_dist_esm_ion-toast_entry_js"],
        "./ion-toggle.entry.js": [55404, "common", "node_modules_ionic_core_dist_esm_ion-toggle_entry_js"],
        "./ion-virtual-scroll.entry.js": [39043, "node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"]
      };

      function webpackAsyncContext(req) {
        if (!__webpack_require__.o(map, req)) {
          return Promise.resolve().then(function () {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = 'MODULE_NOT_FOUND';
            throw e;
          });
        }

        var ids = map[req],
            id = ids[0];
        return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
          return __webpack_require__(id);
        });
      }

      webpackAsyncContext.keys = function () {
        return Object.keys(map);
      };

      webpackAsyncContext.id = 50863;
      module.exports = webpackAsyncContext;
      /***/
    },

    /***/
    75158:
    /*!***************************************************************************************************!*\
      !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/app.component.html ***!
      \***************************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-app>\r\n    <ion-split-pane contentId=\"main-content\">\r\n        <ion-menu contentId=\"main-content\" type=\"overlay\">\r\n            <ion-content>\r\n                <ion-list id=\"side_menu\" lines=\"none\">\r\n                    <ion-list-header>Base de données</ion-list-header>\r\n                    <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\r\n                        <ion-item routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\" routerLinkActive=\"selected\" >\r\n                            <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\r\n                            <ion-label>{{ p.title }}</ion-label>\r\n                        </ion-item>\r\n                    </ion-menu-toggle>\r\n                </ion-list>\r\n\r\n                <ion-list *ngIf=\"authService.currentTokenValue\" lines=\"none\">\r\n                    <ion-list-header>\r\n                        Compte : {{ authService.currentUserValue.username }}\r\n                    </ion-list-header>\r\n\r\n                    <ion-menu-toggle *ngIf=\"authService.currentTokenValue\" auto-hide=\"false\">\r\n                        <ion-item routerLink=\"/sync\" routerLinkActive=\"selected\" routerDirection=\"root\" detail=\"false\">\r\n                            <ion-icon slot=\"start\" name=\"cog\"></ion-icon>\r\n                            <ion-label>Administration</ion-label>\r\n                        </ion-item>\r\n                    </ion-menu-toggle>\r\n\r\n                    <ion-menu-toggle autoHide=\"false\">\r\n                        <ion-item button (click)=\"logout()\" detail=\"false\" routerLinkActive=\"active\" routerLinkActive=\"selected\">\r\n                            <ion-icon slot=\"start\" name=\"log-out\"></ion-icon>\r\n                            <ion-label>\r\n                                Se déconnecter\r\n                            </ion-label>\r\n                        </ion-item>\r\n                    </ion-menu-toggle>\r\n\r\n                </ion-list>\r\n\r\n                <ion-list *ngIf=\"!authService.currentTokenValue\" lines=\"none\">\r\n                    <ion-list-header>\r\n                        Espace membre\r\n                    </ion-list-header>\r\n\r\n                    <ion-menu-toggle autoHide=\"false\">\r\n                        <ion-item routerLink=\"/login\" routerLinkActive=\"active\" routerDirection=\"root\" detail=\"false\" routerLinkActive=\"selected\">\r\n                            <ion-icon slot=\"start\" name=\"log-in\"></ion-icon>\r\n                            <ion-label>\r\n                                Se connecter\r\n                            </ion-label>\r\n                        </ion-item>\r\n                    </ion-menu-toggle>\r\n\r\n                    <ion-menu-toggle autoHide=\"false\">\r\n                        <ion-item routerLink=\"/signup\" routerLinkActive=\"active\" routerDirection=\"root\" detail=\"false\" routerLinkActive=\"selected\">\r\n                            <ion-icon slot=\"start\" name=\"person-add\"></ion-icon>\r\n                            <ion-label>\r\n                                Créer un compte\r\n                            </ion-label>\r\n                        </ion-item>\r\n                    </ion-menu-toggle>\r\n                </ion-list>\r\n\r\n            </ion-content>\r\n        </ion-menu>\r\n        <ion-router-outlet id=\"main-content\"></ion-router-outlet>\r\n    </ion-split-pane>\r\n</ion-app>";
      /***/
    },

    /***/
    53040:
    /*!************************************!*\
      !*** ./src/app/app.component.scss ***!
      \************************************/

    /***/
    function _(module) {
      "use strict";

      module.exports = "ion-menu ion-content {\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\n/* Remove background transitions for switching themes */\n\nion-menu ion-item {\n  --transition: none;\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\n/*\n * Material Design Menu\n*/\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-list-header {\n  padding-left: 18px;\n  padding-right: 18px;\n  text-transform: uppercase;\n  letter-spacing: 0.1em;\n  font-weight: 450;\n}\n\nion-menu.md ion-item {\n  --padding-start: 18px;\n  margin-right: 10px;\n  border-radius: 0 50px 50px 0;\n  font-weight: 500;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-item ion-icon {\n  color: #5f6368;\n  color: var(--ion-color-step-650, #5f6368);\n}\n\nion-menu.md ion-list:not(:last-of-type) {\n  border-bottom: 1px solid #d7d8da;\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\n/*\n * iOS Menu\n*/\n\nion-menu.ios ion-list-header {\n  padding-left: 16px;\n  padding-right: 16px;\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG1CQUFBO0VBQ0Esc0JBQUE7RUFFQSwyRUFBQTtBQUFKOztBQUdFLHVEQUFBOztBQUNBO0VBQ0Usa0JBQUE7QUFBSjs7QUFHRTtFQUNFLGlDQUFBO0FBQUo7O0FBR0U7O0NBQUE7O0FBR0E7RUFDRSxlQUFBO0FBQUo7O0FBR0U7RUFDRSxrQkFBQTtFQUNBLG1CQUFBO0VBRUEseUJBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0FBREo7O0FBSUU7RUFDRSxxQkFBQTtFQUVBLGtCQUFBO0VBRUEsNEJBQUE7RUFFQSxnQkFBQTtBQUpKOztBQU9FO0VBQ0Usc0RBQUE7QUFKSjs7QUFPRTtFQUNFLCtCQUFBO0FBSko7O0FBT0U7O0VBRUUsY0FBQTtFQUFBLHlDQUFBO0FBSko7O0FBT0U7RUFDRSxnQ0FBQTtFQUFBLDJEQUFBO0FBSko7O0FBUUU7O0NBQUE7O0FBR0E7RUFDRSxrQkFBQTtFQUNBLG1CQUFBO0VBRUEsa0JBQUE7QUFOSjs7QUFTRTtFQUNFLGlCQUFBO0FBTko7O0FBU0U7RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0FBTko7O0FBU0U7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQU5KOztBQVNFO0VBQ0UsK0JBQUE7QUFOSiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudSBpb24tY29udGVudCB7XHJcbiAgICAtLXBhZGRpbmctdG9wOiAyMHB4O1xyXG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcclxuICBcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWl0ZW0tYmFja2dyb3VuZCwgdmFyKC0taW9uLWJhY2tncm91bmQtY29sb3IsICNmZmYpKTtcclxuICB9XHJcbiAgXHJcbiAgLyogUmVtb3ZlIGJhY2tncm91bmQgdHJhbnNpdGlvbnMgZm9yIHN3aXRjaGluZyB0aGVtZXMgKi9cclxuICBpb24tbWVudSBpb24taXRlbSB7XHJcbiAgICAtLXRyYW5zaXRpb246IG5vbmU7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1pdGVtLnNlbGVjdGVkIHtcclxuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICB9XHJcbiAgXHJcbiAgLypcclxuICAgKiBNYXRlcmlhbCBEZXNpZ24gTWVudVxyXG4gICovXHJcbiAgaW9uLW1lbnUubWQgaW9uLWxpc3Qge1xyXG4gICAgcGFkZGluZzogMjBweCAwO1xyXG4gIH1cclxuICBcclxuICBpb24tbWVudS5tZCBpb24tbGlzdC1oZWFkZXIge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMThweDtcclxuICBcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICBsZXR0ZXItc3BhY2luZzogLjFlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiA0NTA7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtIHtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMThweDtcclxuICBcclxuICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuICBcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgNTBweCA1MHB4IDA7XHJcbiAgXHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gIH1cclxuICBcclxuICBpb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLXByaW1hcnktcmdiKSwgMC4xNCk7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcclxuICBpb24tbWVudS5tZCBpb24taXRlbSBpb24taWNvbiB7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXN0ZXAtNjUwLCAjNWY2MzY4KTtcclxuICB9XHJcbiAgXHJcbiAgaW9uLW1lbnUubWQgaW9uLWxpc3Q6bm90KDpsYXN0LW9mLXR5cGUpIHtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itc3RlcC0xNTAsICNkN2Q4ZGEpO1xyXG4gIH1cclxuICBcclxuICBcclxuICAvKlxyXG4gICAqIGlPUyBNZW51XHJcbiAgKi9cclxuICBpb24tbWVudS5pb3MgaW9uLWxpc3QtaGVhZGVyIHtcclxuICAgIHBhZGRpbmctbGVmdDogMTZweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDE2cHg7XHJcbiAgXHJcbiAgICBtYXJnaW4tYm90dG9tOiA4cHg7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1tZW51LmlvcyBpb24tbGlzdCB7XHJcbiAgICBwYWRkaW5nOiAyMHB4IDAgMDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLW1lbnUuaW9zIGlvbi1pdGVtIHtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMTZweDtcclxuICAgIC0tbWluLWhlaWdodDogNTBweDtcclxuICB9XHJcbiAgXHJcbiAgaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgIGNvbG9yOiAjNzM4NDlhO1xyXG4gIH1cclxuICBcclxuICBpb24tbWVudS5pb3MgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICB9XHJcbiAgIl19 */";
      /***/
    }
  },
  /******/
  function (__webpack_require__) {
    // webpackRuntimeModules

    /******/
    var __webpack_exec__ = function __webpack_exec__(moduleId) {
      return __webpack_require__(__webpack_require__.s = moduleId);
    };
    /******/


    __webpack_require__.O(0, ["vendor"], function () {
      return __webpack_exec__(14431);
    });
    /******/


    var __webpack_exports__ = __webpack_require__.O();
    /******/

  }]);
})();
//# sourceMappingURL=main-es5.js.map