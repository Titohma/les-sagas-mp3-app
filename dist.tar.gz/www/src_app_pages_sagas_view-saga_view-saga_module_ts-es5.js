(function () {
  "use strict";

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

  function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  (self["webpackChunkles_sagas_mp3"] = self["webpackChunkles_sagas_mp3"] || []).push([["src_app_pages_sagas_view-saga_view-saga_module_ts"], {
    /***/
    90184:
    /*!************************************!*\
      !*** ./src/app/entities/season.ts ***!
      \************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "Season": function Season() {
          return (
            /* binding */
            _Season
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _models_season_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../models/season.model */
      54747);

      var _Season = /*#__PURE__*/function (_models_season_model_) {
        _inherits(_Season, _models_season_model_);

        var _super = _createSuper(_Season);

        function _Season() {
          _classCallCheck(this, _Season);

          return _super.apply(this, arguments);
        }

        _createClass(_Season, null, [{
          key: "fromModel",
          value: function fromModel(model) {
            var entity = new _Season();
            entity.id = model.id;
            entity.createdAt = model.createdAt;
            entity.createdBy = model.createdBy;
            entity.updatedAt = model.updatedAt;
            entity.updatedBy = model.updatedBy;
            entity.number = model.number;
            entity.name = model.name;
            entity.sagaRef = model.sagaRef;
            entity.episodesRef = model.episodesRef;
            return entity;
          }
        }, {
          key: "fromModels",
          value: function fromModels(models) {
            var _this = this;

            var entities = [];
            models.forEach(function (model) {
              return entities.push(_this.fromModel(model));
            });
            return entities;
          }
        }]);

        return _Season;
      }(_models_season_model__WEBPACK_IMPORTED_MODULE_0__.SeasonModel);
      /***/

    },

    /***/
    54747:
    /*!****************************************!*\
      !*** ./src/app/models/season.model.ts ***!
      \****************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SeasonModel": function SeasonModel() {
          return (
            /* binding */
            _SeasonModel
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _audit_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./audit.model */
      3809);

      var _SeasonModel = /*#__PURE__*/function (_audit_model__WEBPACK) {
        _inherits(_SeasonModel, _audit_model__WEBPACK);

        var _super2 = _createSuper(_SeasonModel);

        function _SeasonModel() {
          var _this2;

          _classCallCheck(this, _SeasonModel);

          _this2 = _super2.apply(this, arguments);
          _this2.number = 1;
          _this2.name = '';
          _this2.sagaRef = 0;
          _this2.episodesRef = [];
          return _this2;
        }

        return _SeasonModel;
      }(_audit_model__WEBPACK_IMPORTED_MODULE_0__.AuditModel);
      /***/

    },

    /***/
    9795:
    /*!*******************************************************************!*\
      !*** ./src/app/pages/sagas/view-saga/view-saga-routing.module.ts ***!
      \*******************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ViewSagaPageRoutingModule": function ViewSagaPageRoutingModule() {
          return (
            /* binding */
            _ViewSagaPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      71258);
      /* harmony import */


      var _view_saga_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./view-saga.page */
      53936);

      var routes = [{
        path: '',
        component: _view_saga_page__WEBPACK_IMPORTED_MODULE_0__.ViewSagaPage
      }];

      var _ViewSagaPageRoutingModule = function ViewSagaPageRoutingModule() {
        _classCallCheck(this, ViewSagaPageRoutingModule);
      };

      _ViewSagaPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _ViewSagaPageRoutingModule);
      /***/
    },

    /***/
    64812:
    /*!***********************************************************!*\
      !*** ./src/app/pages/sagas/view-saga/view-saga.module.ts ***!
      \***********************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ViewSagaPageModule": function ViewSagaPageModule() {
          return (
            /* binding */
            _ViewSagaPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      54364);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      1707);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      7602);
      /* harmony import */


      var _view_saga_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./view-saga-routing.module */
      9795);
      /* harmony import */


      var _view_saga_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./view-saga.page */
      53936);

      var _ViewSagaPageModule = function ViewSagaPageModule() {
        _classCallCheck(this, ViewSagaPageModule);
      };

      _ViewSagaPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _view_saga_routing_module__WEBPACK_IMPORTED_MODULE_0__.ViewSagaPageRoutingModule],
        declarations: [_view_saga_page__WEBPACK_IMPORTED_MODULE_1__.ViewSagaPage]
      })], _ViewSagaPageModule);
      /***/
    },

    /***/
    53936:
    /*!*********************************************************!*\
      !*** ./src/app/pages/sagas/view-saga/view-saga.page.ts ***!
      \*********************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ViewSagaPage": function ViewSagaPage() {
          return (
            /* binding */
            _ViewSagaPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_view_saga_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./view-saga.page.html */
      23544);
      /* harmony import */


      var _view_saga_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./view-saga.page.scss */
      28103);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/router */
      71258);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @ionic/angular */
      7602);
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! rxjs */
      42720);
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! src/environments/environment */
      92340);
      /* harmony import */


      var src_app_entities_category__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/entities/category */
      15361);
      /* harmony import */


      var src_app_entities_saga__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/entities/saga */
      40373);
      /* harmony import */


      var src_app_entities_season__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/entities/season */
      90184);
      /* harmony import */


      var src_app_services_authors_author_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/services/authors/author.service */
      50623);
      /* harmony import */


      var src_app_services_categories_category_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/services/categories/category.service */
      16471);
      /* harmony import */


      var src_app_services_sagas_saga_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! src/app/services/sagas/saga.service */
      24041);
      /* harmony import */


      var src_app_services_seasons_season_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! src/app/services/seasons/season.service */
      26183);

      var _ViewSagaPage = /*#__PURE__*/function () {
        function ViewSagaPage(activatedRoute, loadingController, authorService, categoryService, sagaService, seasonService) {
          _classCallCheck(this, ViewSagaPage);

          this.activatedRoute = activatedRoute;
          this.loadingController = loadingController;
          this.authorService = authorService;
          this.categoryService = categoryService;
          this.sagaService = sagaService;
          this.seasonService = seasonService;
          this.item = new src_app_entities_saga__WEBPACK_IMPORTED_MODULE_4__.Saga();
        }

        _createClass(ViewSagaPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this3 = this;

            var itemId = +this.activatedRoute.snapshot.paramMap.get('id');
            this.loadingController.create({
              message: 'Téléchargement...'
            }).then(function (loading) {
              loading.present();

              _this3.sagaService.getById(itemId).subscribe(function (data) {
                _this3.item = src_app_entities_saga__WEBPACK_IMPORTED_MODULE_4__.Saga.fromModel(data);

                var categories = _this3.categoryService.getAllByIds(data.categoriesRef);

                var authors = _this3.authorService.getAllByIds(data.authorsRef);

                var seasons = _this3.seasonService.getAllByIds(data.seasonsRef);

                (0, rxjs__WEBPACK_IMPORTED_MODULE_10__.forkJoin)([authors, categories, seasons]).subscribe(function (results) {
                  _this3.item.authors = results[0];
                  _this3.item.categories = src_app_entities_category__WEBPACK_IMPORTED_MODULE_3__.Category.fromModels(results[1]);
                  _this3.item.seasons = src_app_entities_season__WEBPACK_IMPORTED_MODULE_5__.Season.fromModels(results[2]);
                  loading.dismiss();
                });
              });
            });
          }
        }, {
          key: "bannerUrl",
          value: function bannerUrl() {
            if (this.item.bannerUrl) {
              return 'url(' + src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.webUrl + this.item.bannerUrl + ')';
            } else {
              return '';
            }
          }
        }, {
          key: "coverUrl",
          value: function coverUrl() {
            if (this.item.coverUrl) {
              return src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.webUrl + this.item.coverUrl;
            } else {
              return '';
            }
          }
        }]);

        return ViewSagaPage;
      }();

      _ViewSagaPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.LoadingController
        }, {
          type: src_app_services_authors_author_service__WEBPACK_IMPORTED_MODULE_6__.AuthorService
        }, {
          type: src_app_services_categories_category_service__WEBPACK_IMPORTED_MODULE_7__.CategoryService
        }, {
          type: src_app_services_sagas_saga_service__WEBPACK_IMPORTED_MODULE_8__.SagaService
        }, {
          type: src_app_services_seasons_season_service__WEBPACK_IMPORTED_MODULE_9__.SeasonService
        }];
      };

      _ViewSagaPage = (0, tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_14__.Component)({
        selector: 'app-view-saga',
        template: _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_view_saga_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_view_saga_page_scss__WEBPACK_IMPORTED_MODULE_1__]
      })], _ViewSagaPage);
      /***/
    },

    /***/
    50623:
    /*!****************************************************!*\
      !*** ./src/app/services/authors/author.service.ts ***!
      \****************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "AuthorService": function AuthorService() {
          return (
            /* binding */
            _AuthorService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      53882);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _config_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../config/config.service */
      88939);

      var _AuthorService = /*#__PURE__*/function () {
        function AuthorService(http, configService) {
          _classCallCheck(this, AuthorService);

          this.http = http;
          this.configService = configService;
        }

        _createClass(AuthorService, [{
          key: "getAllByIds",
          value: function getAllByIds(ids) {
            var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams().set('ids', ids.toString());
            return this.http.get("".concat(this.configService.get('apiUrl'), "/authors"), {
              params: params
            });
          }
        }]);

        return AuthorService;
      }();

      _AuthorService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
        }, {
          type: _config_config_service__WEBPACK_IMPORTED_MODULE_0__.ConfigService
        }];
      };

      _AuthorService = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
      })], _AuthorService);
      /***/
    },

    /***/
    26183:
    /*!****************************************************!*\
      !*** ./src/app/services/seasons/season.service.ts ***!
      \****************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SeasonService": function SeasonService() {
          return (
            /* binding */
            _SeasonService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      53882);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _config_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../config/config.service */
      88939);

      var _SeasonService = /*#__PURE__*/function () {
        function SeasonService(http, configService) {
          _classCallCheck(this, SeasonService);

          this.http = http;
          this.configService = configService;
        }

        _createClass(SeasonService, [{
          key: "getAllByIds",
          value: function getAllByIds(ids) {
            var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams().set('ids', ids.toString());
            return this.http.get("".concat(this.configService.get('apiUrl'), "/season"), {
              params: params
            });
          }
        }]);

        return SeasonService;
      }();

      _SeasonService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
        }, {
          type: _config_config_service__WEBPACK_IMPORTED_MODULE_0__.ConfigService
        }];
      };

      _SeasonService = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
      })], _SeasonService);
      /***/
    },

    /***/
    23544:
    /*!**************************************************************************************************************************!*\
      !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/sagas/view-saga/view-saga.page.html ***!
      \**************************************************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\r\n    <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n            <ion-menu-button></ion-menu-button>\r\n            <ion-back-button></ion-back-button>\r\n        </ion-buttons>\r\n        <ion-title>{{ item.title }}</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n    <div class=\"background\" [ngStyle]=\"{'background-image': bannerUrl()}\">\r\n        <div class=\"background-left-buttons\">\r\n            <ion-button *ngIf=\"item.url\" color=\"light\" href=\"{{ item.url }}\">\r\n                <ion-icon slot=\"start\" name=\"globe\"></ion-icon>\r\n                Site\r\n            </ion-button>\r\n            <ion-button *ngIf=\"item.urlWiki\" color=\"light\" href=\"{{ item.urlWiki }}\">\r\n                <ion-icon slot=\"start\" name=\"globe\"></ion-icon>\r\n                Wiki\r\n            </ion-button>\r\n        </div>\r\n        <ion-img class=\"cover\" [src]=\"coverUrl()\"></ion-img>\r\n    </div>\r\n    <ion-list>\r\n        <ion-item lines=\"none\">\r\n            <ion-icon slot=\"start\" name=\"person\"></ion-icon>\r\n            <span *ngFor=\"let author of item.authors; let isLast=last\">\r\n                {{ author.name }}{{isLast ? '' : ', '}}\r\n            </span>\r\n        </ion-item>\r\n        <ion-item lines=\"none\">\r\n            <ion-icon slot=\"start\" name=\"bookmarks\"></ion-icon>\r\n            <ion-badge *ngFor=\"let category of item.categories\" class=\"categoryBadge\" color=\"medium\">\r\n                {{ category.name }}\r\n            </ion-badge>\r\n        </ion-item>\r\n        <ion-grid>\r\n            <ion-row>\r\n                <ion-col size=\"4\">\r\n                    <ion-item>\r\n                        <ion-icon class=\"icon-center\" name=\"color-palette\"></ion-icon>\r\n                    </ion-item>\r\n                </ion-col>\r\n                <ion-col size=\"4\">\r\n                    <ion-item>\r\n                        <ion-icon class=\"icon-center\" name=\"construct\"></ion-icon>\r\n                    </ion-item>\r\n                </ion-col>\r\n                <ion-col size=\"4\">\r\n                    <ion-item>\r\n                        <ion-icon class=\"icon-center\" name=\"thumbs-up\"></ion-icon>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col class=\"ion-text-center\" size=\"4\">\r\n                    {{ item.levelArt * 100 / 200 }} %\r\n                </ion-col>\r\n                <ion-col class=\"ion-text-center\" size=\"4\">\r\n                    {{ item.levelTech * 100 / 200 }} %\r\n                </ion-col>\r\n                <ion-col class=\"ion-text-center\" size=\"4\">\r\n                    {{ item.nbBravos }}\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n        <div *ngIf=\"item.seasonsRef.length > 0\">\r\n            <ion-list-header>\r\n                <ion-label>Saisons</ion-label>\r\n            </ion-list-header>\r\n            <ion-item *ngFor=\"let season of item.seasons\">\r\n                <ion-label>\r\n                    <h2>Saison {{ season.number }} {{ season.name }}</h2>\r\n                </ion-label>\r\n            </ion-item>\r\n        </div>\r\n    </ion-list>\r\n\r\n</ion-content>";
      /***/
    },

    /***/
    28103:
    /*!***********************************************************!*\
      !*** ./src/app/pages/sagas/view-saga/view-saga.page.scss ***!
      \***********************************************************/

    /***/
    function _(module) {
      module.exports = ".background {\n  width: 100%;\n  height: 7em;\n  background-color: grey;\n  background-size: auto 7em;\n}\n\n.cover {\n  float: right;\n  width: 5em;\n  height: 5em;\n  border: 1px solid white;\n  margin: 1em;\n}\n\n.background-left-buttons {\n  float: left;\n  margin-top: 2em;\n  margin-left: 1em;\n}\n\n.categoryBadge {\n  margin-right: 0.2em;\n}\n\n.icon-center {\n  position: absolute;\n  top: 50%;\n  left: 40%;\n  height: 50%;\n  transform: translate(-50%, -50%);\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZpZXctc2FnYS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsV0FBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7QUFDSjs7QUFFQTtFQUNJLFlBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtBQUNKOztBQUVBO0VBQ0ksV0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVBO0VBQ0ksbUJBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsZ0NBQUE7RUFDQSxjQUFBO0FBQ0oiLCJmaWxlIjoidmlldy1zYWdhLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5iYWNrZ3JvdW5kIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA3ZW07XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmV5O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBhdXRvIDdlbTtcclxufVxyXG5cclxuLmNvdmVyIHtcclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIHdpZHRoOiA1ZW07XHJcbiAgICBoZWlnaHQ6IDVlbTtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xyXG4gICAgbWFyZ2luOiAxZW07XHJcbn1cclxuXHJcbi5iYWNrZ3JvdW5kLWxlZnQtYnV0dG9ucyB7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIG1hcmdpbi10b3A6IDJlbTtcclxuICAgIG1hcmdpbi1sZWZ0OiAxZW07XHJcbn1cclxuXHJcbi5jYXRlZ29yeUJhZGdlIHtcclxuICAgIG1hcmdpbi1yaWdodDogLjJlbTtcclxufVxyXG5cclxuLmljb24tY2VudGVyIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgbGVmdDogNDAlO1xyXG4gICAgaGVpZ2h0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59Il19 */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_pages_sagas_view-saga_view-saga_module_ts-es5.js.map