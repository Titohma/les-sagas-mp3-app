(function () {
  "use strict";

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

  function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  (self["webpackChunkles_sagas_mp3"] = self["webpackChunkles_sagas_mp3"] || []).push([["src_app_pages_admin_sync_sync_module_ts"], {
    /***/
    12042:
    /*!******************************************!*\
      !*** ./src/app/models/eventlog.model.ts ***!
      \******************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "EventLogModel": function EventLogModel() {
          return (
            /* binding */
            _EventLogModel
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _audit_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./audit.model */
      3809);

      var _EventLogModel = /*#__PURE__*/function (_audit_model__WEBPACK) {
        _inherits(_EventLogModel, _audit_model__WEBPACK);

        var _super = _createSuper(_EventLogModel);

        function _EventLogModel() {
          _classCallCheck(this, _EventLogModel);

          return _super.apply(this, arguments);
        }

        return _EventLogModel;
      }(_audit_model__WEBPACK_IMPORTED_MODULE_0__.AuditModel);
      /***/

    },

    /***/
    73321:
    /*!*********************************************************!*\
      !*** ./src/app/pages/admin/sync/sync-routing.module.ts ***!
      \*********************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SyncPageRoutingModule": function SyncPageRoutingModule() {
          return (
            /* binding */
            _SyncPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      71258);
      /* harmony import */


      var _sync_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./sync.page */
      36104);

      var routes = [{
        path: '',
        component: _sync_page__WEBPACK_IMPORTED_MODULE_0__.SyncPage
      }];

      var _SyncPageRoutingModule = function SyncPageRoutingModule() {
        _classCallCheck(this, SyncPageRoutingModule);
      };

      _SyncPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _SyncPageRoutingModule);
      /***/
    },

    /***/
    26714:
    /*!*************************************************!*\
      !*** ./src/app/pages/admin/sync/sync.module.ts ***!
      \*************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SyncPageModule": function SyncPageModule() {
          return (
            /* binding */
            _SyncPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      54364);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      1707);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      7602);
      /* harmony import */


      var _sync_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./sync-routing.module */
      73321);
      /* harmony import */


      var _sync_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./sync.page */
      36104);

      var _SyncPageModule = function SyncPageModule() {
        _classCallCheck(this, SyncPageModule);
      };

      _SyncPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _sync_routing_module__WEBPACK_IMPORTED_MODULE_0__.SyncPageRoutingModule],
        declarations: [_sync_page__WEBPACK_IMPORTED_MODULE_1__.SyncPage]
      })], _SyncPageModule);
      /***/
    },

    /***/
    36104:
    /*!***********************************************!*\
      !*** ./src/app/pages/admin/sync/sync.page.ts ***!
      \***********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SyncPage": function SyncPage() {
          return (
            /* binding */
            _SyncPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_sync_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./sync.page.html */
      52693);
      /* harmony import */


      var _sync_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./sync.page.scss */
      69535);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      7602);
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! rxjs */
      42720);
      /* harmony import */


      var src_app_models_eventlog_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! src/app/models/eventlog.model */
      12042);
      /* harmony import */


      var src_app_services_eventlog_eventlog_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/services/eventlog/eventlog.service */
      79159);
      /* harmony import */


      var src_app_services_sync_sync_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/services/sync/sync.service */
      74217);

      var _SyncPage = /*#__PURE__*/function () {
        function SyncPage(loadingController, eventLogService, syncService) {
          _classCallCheck(this, SyncPage);

          this.loadingController = loadingController;
          this.eventLogService = eventLogService;
          this.syncService = syncService;
          this.lastSyncNews = new src_app_models_eventlog_model__WEBPACK_IMPORTED_MODULE_2__.EventLogModel();
          this.lastSyncSagas = new src_app_models_eventlog_model__WEBPACK_IMPORTED_MODULE_2__.EventLogModel();
        }

        _createClass(SyncPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.loadingController.create({
              message: 'Téléchargement...'
            }).then(function (loading) {
              loading.present();

              var syncNewsRequest = _this.eventLogService.getLatestByName("SYNC_NEWS_START");

              var syncSagasRequest = _this.eventLogService.getLatestByName("SYNC_SAGAS_START");

              (0, rxjs__WEBPACK_IMPORTED_MODULE_5__.forkJoin)([syncNewsRequest, syncSagasRequest]).subscribe(function (results) {
                _this.lastSyncNews = results[0];
                _this.lastSyncSagas = results[1];
                loading.dismiss();
              }, function (error) {
                loading.dismiss();
              });
            });
          }
        }, {
          key: "doRefresh",
          value: function doRefresh(event) {
            var _this2 = this;

            var syncNewsRequest = this.eventLogService.getLatestByName("SYNC_NEWS_START");
            var syncSagasRequest = this.eventLogService.getLatestByName("SYNC_SAGAS_START");
            (0, rxjs__WEBPACK_IMPORTED_MODULE_5__.forkJoin)([syncNewsRequest, syncSagasRequest]).subscribe(function (results) {
              _this2.lastSyncNews = results[0];
              _this2.lastSyncSagas = results[1];
              event.target.complete();
            }, function (error) {
              event.target.complete();
            });
          }
        }, {
          key: "syncNews",
          value: function syncNews() {
            this.syncService.syncNews().subscribe(function (res) {});
          }
        }, {
          key: "syncSagas",
          value: function syncSagas() {
            this.syncService.syncSagas().subscribe(function (res) {});
          }
        }]);

        return SyncPage;
      }();

      _SyncPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController
        }, {
          type: src_app_services_eventlog_eventlog_service__WEBPACK_IMPORTED_MODULE_3__.EventLogService
        }, {
          type: src_app_services_sync_sync_service__WEBPACK_IMPORTED_MODULE_4__.SyncService
        }];
      };

      _SyncPage = (0, tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-sync',
        template: _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_sync_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_sync_page_scss__WEBPACK_IMPORTED_MODULE_1__]
      })], _SyncPage);
      /***/
    },

    /***/
    79159:
    /*!*******************************************************!*\
      !*** ./src/app/services/eventlog/eventlog.service.ts ***!
      \*******************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "EventLogService": function EventLogService() {
          return (
            /* binding */
            _EventLogService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      53882);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _config_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../config/config.service */
      88939);

      var _EventLogService = /*#__PURE__*/function () {
        function EventLogService(http, configService) {
          _classCallCheck(this, EventLogService);

          this.http = http;
          this.configService = configService;
        }

        _createClass(EventLogService, [{
          key: "getLatestByName",
          value: function getLatestByName(name) {
            var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams().set('name', name);
            return this.http.get("".concat(this.configService.get('apiUrl'), "/eventlogs"), {
              params: params
            });
          }
        }]);

        return EventLogService;
      }();

      _EventLogService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
        }, {
          type: _config_config_service__WEBPACK_IMPORTED_MODULE_0__.ConfigService
        }];
      };

      _EventLogService = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
      })], _EventLogService);
      /***/
    },

    /***/
    74217:
    /*!***********************************************!*\
      !*** ./src/app/services/sync/sync.service.ts ***!
      \***********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SyncService": function SyncService() {
          return (
            /* binding */
            _SyncService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      53882);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _config_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../config/config.service */
      88939);

      var _SyncService = /*#__PURE__*/function () {
        function SyncService(http, configService) {
          _classCallCheck(this, SyncService);

          this.http = http;
          this.configService = configService;
        }

        _createClass(SyncService, [{
          key: "syncNews",
          value: function syncNews() {
            return this.http.post("".concat(this.configService.get('apiUrl'), "/sync/news"), {});
          }
        }, {
          key: "syncSagas",
          value: function syncSagas() {
            return this.http.post("".concat(this.configService.get('apiUrl'), "/sync/sagas"), {});
          }
        }]);

        return SyncService;
      }();

      _SyncService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
        }, {
          type: _config_config_service__WEBPACK_IMPORTED_MODULE_0__.ConfigService
        }];
      };

      _SyncService = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
      })], _SyncService);
      /***/
    },

    /***/
    52693:
    /*!****************************************************************************************************************!*\
      !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/admin/sync/sync.page.html ***!
      \****************************************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\r\n    <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n            <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>Synchronisation</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n\r\n    <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\r\n        <ion-refresher-content></ion-refresher-content>\r\n    </ion-refresher>\r\n    <ion-list>\r\n        <ion-item-divider>\r\n            <ion-label>\r\n                Actualités\r\n            </ion-label>\r\n        </ion-item-divider>\r\n        <ion-item lines=\"none\">\r\n            Dernière exécution\r\n            <span slot=\"end\">{{ lastSyncNews.createdAt | date:'d/MM/yy HH:mm':'fr' }}</span>\r\n        </ion-item>\r\n        <ion-item>\r\n            <ion-button expand=\"block\" style=\"width: 100%\" (click)=\"syncNews()\">\r\n                <ion-icon slot=\"start\" name=\"paper-plane\"></ion-icon>\r\n                Lancer maintenant\r\n            </ion-button>\r\n        </ion-item>\r\n        <ion-item-divider>\r\n            <ion-label>\r\n                Liste des sagas\r\n            </ion-label>\r\n        </ion-item-divider>\r\n        <ion-item lines=\"none\">\r\n            Dernière exécution\r\n            <span slot=\"end\">{{ lastSyncSagas.createdAt | date:'d/MM/yy HH:mm':'fr' }}</span>\r\n        </ion-item>\r\n        <ion-item>\r\n            <ion-button expand=\"block\" style=\"width: 100%\" (click)=\"syncSagas()\">\r\n                <ion-icon slot=\"start\" name=\"paper-plane\"></ion-icon>\r\n                Lancer maintenant\r\n            </ion-button>\r\n        </ion-item>\r\n    </ion-list>\r\n</ion-content>";
      /***/
    },

    /***/
    69535:
    /*!*************************************************!*\
      !*** ./src/app/pages/admin/sync/sync.page.scss ***!
      \*************************************************/

    /***/
    function _(module) {
      module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzeW5jLnBhZ2Uuc2NzcyJ9 */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_pages_admin_sync_sync_module_ts-es5.js.map