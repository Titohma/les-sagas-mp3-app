"use strict";
(self["webpackChunkles_sagas_mp3"] = self["webpackChunkles_sagas_mp3"] || []).push([["src_app_pages_news_view-news_view-news_module_ts"],{

/***/ 34956:
/*!*********************************************!*\
  !*** ./src/app/models/rss.message.model.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RssMessageModel": function() { return /* binding */ RssMessageModel; }
/* harmony export */ });
/* harmony import */ var _audit_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./audit.model */ 3809);

class RssMessageModel extends _audit_model__WEBPACK_IMPORTED_MODULE_0__.AuditModel {
    constructor() {
        super(...arguments);
        this.feedTitle = '';
        this.title = '';
        this.pubdate = new Date();
        this.description = '';
        this.link = '';
        this.author = '';
        this.guid = '';
    }
}


/***/ }),

/***/ 91564:
/*!******************************************************************!*\
  !*** ./src/app/pages/news/view-news/view-news-routing.module.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViewNewsPageRoutingModule": function() { return /* binding */ ViewNewsPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _view_news_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./view-news.page */ 99358);




const routes = [
    {
        path: '',
        component: _view_news_page__WEBPACK_IMPORTED_MODULE_0__.ViewNewsPage
    }
];
let ViewNewsPageRoutingModule = class ViewNewsPageRoutingModule {
};
ViewNewsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ViewNewsPageRoutingModule);



/***/ }),

/***/ 7607:
/*!**********************************************************!*\
  !*** ./src/app/pages/news/view-news/view-news.module.ts ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViewNewsPageModule": function() { return /* binding */ ViewNewsPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 7602);
/* harmony import */ var _view_news_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./view-news-routing.module */ 91564);
/* harmony import */ var _view_news_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./view-news.page */ 99358);







let ViewNewsPageModule = class ViewNewsPageModule {
};
ViewNewsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _view_news_routing_module__WEBPACK_IMPORTED_MODULE_0__.ViewNewsPageRoutingModule
        ],
        declarations: [_view_news_page__WEBPACK_IMPORTED_MODULE_1__.ViewNewsPage]
    })
], ViewNewsPageModule);



/***/ }),

/***/ 99358:
/*!********************************************************!*\
  !*** ./src/app/pages/news/view-news/view-news.page.ts ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViewNewsPage": function() { return /* binding */ ViewNewsPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_view_news_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./view-news.page.html */ 13282);
/* harmony import */ var _view_news_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./view-news.page.scss */ 50282);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 7602);
/* harmony import */ var src_app_services_rss_message_rss_message_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/rss.message/rss.message.service */ 36232);
/* harmony import */ var src_app_models_rss_message_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/models/rss.message.model */ 34956);








let ViewNewsPage = class ViewNewsPage {
    constructor(activatedRoute, loadingController, rssMessageService) {
        this.activatedRoute = activatedRoute;
        this.loadingController = loadingController;
        this.rssMessageService = rssMessageService;
        this.item = new src_app_models_rss_message_model__WEBPACK_IMPORTED_MODULE_3__.RssMessageModel();
    }
    ngOnInit() {
        var itemId = +this.activatedRoute.snapshot.paramMap.get('id');
        this.loadingController.create({
            message: 'Téléchargement...'
        }).then((loading) => {
            loading.present();
            this.rssMessageService.getById(itemId)
                .subscribe(data => {
                this.item = data;
                loading.dismiss();
            });
        });
    }
};
ViewNewsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: src_app_services_rss_message_rss_message_service__WEBPACK_IMPORTED_MODULE_2__.RssMessageService }
];
ViewNewsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-view-news',
        template: _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_view_news_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_view_news_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ViewNewsPage);



/***/ }),

/***/ 13282:
/*!*************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/news/view-news/view-news.page.html ***!
  \*************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n            <ion-back-button></ion-back-button>\n        </ion-buttons>\n        <ion-title>Actualités</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card>\n        <ion-card-header>\n            <ion-card-title>{{ item.title }}</ion-card-title>\n            <ion-card-subtitle>Par {{ item.author }} le {{ item.pubdate | date:'dd/MM/yyyy' }}</ion-card-subtitle>\n        </ion-card-header>\n\n        <ion-card-content>\n            <div [innerHtml]=\"item.description\"></div>\n            <ion-button href=\"{{ item.link }}\" slot=\"end\">Lire sur Netophonix</ion-button>\n        </ion-card-content>\n    </ion-card>\n</ion-content>");

/***/ }),

/***/ 50282:
/*!**********************************************************!*\
  !*** ./src/app/pages/news/view-news/view-news.page.scss ***!
  \**********************************************************/
/***/ (function(module) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2aWV3LW5ld3MucGFnZS5zY3NzIn0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_news_view-news_view-news_module_ts-es2015.js.map