(function () {
  "use strict";

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

  function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  (self["webpackChunkles_sagas_mp3"] = self["webpackChunkles_sagas_mp3"] || []).push([["src_app_pages_news_view-news_view-news_module_ts"], {
    /***/
    34956:
    /*!*********************************************!*\
      !*** ./src/app/models/rss.message.model.ts ***!
      \*********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RssMessageModel": function RssMessageModel() {
          return (
            /* binding */
            _RssMessageModel
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _audit_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./audit.model */
      3809);

      var _RssMessageModel = /*#__PURE__*/function (_audit_model__WEBPACK) {
        _inherits(_RssMessageModel, _audit_model__WEBPACK);

        var _super = _createSuper(_RssMessageModel);

        function _RssMessageModel() {
          var _this;

          _classCallCheck(this, _RssMessageModel);

          _this = _super.apply(this, arguments);
          _this.feedTitle = '';
          _this.title = '';
          _this.pubdate = new Date();
          _this.description = '';
          _this.link = '';
          _this.author = '';
          _this.guid = '';
          return _this;
        }

        return _RssMessageModel;
      }(_audit_model__WEBPACK_IMPORTED_MODULE_0__.AuditModel);
      /***/

    },

    /***/
    91564:
    /*!******************************************************************!*\
      !*** ./src/app/pages/news/view-news/view-news-routing.module.ts ***!
      \******************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ViewNewsPageRoutingModule": function ViewNewsPageRoutingModule() {
          return (
            /* binding */
            _ViewNewsPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      71258);
      /* harmony import */


      var _view_news_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./view-news.page */
      99358);

      var routes = [{
        path: '',
        component: _view_news_page__WEBPACK_IMPORTED_MODULE_0__.ViewNewsPage
      }];

      var _ViewNewsPageRoutingModule = function ViewNewsPageRoutingModule() {
        _classCallCheck(this, ViewNewsPageRoutingModule);
      };

      _ViewNewsPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _ViewNewsPageRoutingModule);
      /***/
    },

    /***/
    7607:
    /*!**********************************************************!*\
      !*** ./src/app/pages/news/view-news/view-news.module.ts ***!
      \**********************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ViewNewsPageModule": function ViewNewsPageModule() {
          return (
            /* binding */
            _ViewNewsPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      54364);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      1707);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      7602);
      /* harmony import */


      var _view_news_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./view-news-routing.module */
      91564);
      /* harmony import */


      var _view_news_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./view-news.page */
      99358);

      var _ViewNewsPageModule = function ViewNewsPageModule() {
        _classCallCheck(this, ViewNewsPageModule);
      };

      _ViewNewsPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _view_news_routing_module__WEBPACK_IMPORTED_MODULE_0__.ViewNewsPageRoutingModule],
        declarations: [_view_news_page__WEBPACK_IMPORTED_MODULE_1__.ViewNewsPage]
      })], _ViewNewsPageModule);
      /***/
    },

    /***/
    99358:
    /*!********************************************************!*\
      !*** ./src/app/pages/news/view-news/view-news.page.ts ***!
      \********************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ViewNewsPage": function ViewNewsPage() {
          return (
            /* binding */
            _ViewNewsPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! tslib */
      3786);
      /* harmony import */


      var _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_view_news_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./view-news.page.html */
      13282);
      /* harmony import */


      var _view_news_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./view-news.page.scss */
      50282);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      71258);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      7602);
      /* harmony import */


      var src_app_services_rss_message_rss_message_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! src/app/services/rss.message/rss.message.service */
      36232);
      /* harmony import */


      var src_app_models_rss_message_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/models/rss.message.model */
      34956);

      var _ViewNewsPage = /*#__PURE__*/function () {
        function ViewNewsPage(activatedRoute, loadingController, rssMessageService) {
          _classCallCheck(this, ViewNewsPage);

          this.activatedRoute = activatedRoute;
          this.loadingController = loadingController;
          this.rssMessageService = rssMessageService;
          this.item = new src_app_models_rss_message_model__WEBPACK_IMPORTED_MODULE_3__.RssMessageModel();
        }

        _createClass(ViewNewsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this2 = this;

            var itemId = +this.activatedRoute.snapshot.paramMap.get('id');
            this.loadingController.create({
              message: 'Téléchargement...'
            }).then(function (loading) {
              loading.present();

              _this2.rssMessageService.getById(itemId).subscribe(function (data) {
                _this2.item = data;
                loading.dismiss();
              });
            });
          }
        }]);

        return ViewNewsPage;
      }();

      _ViewNewsPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController
        }, {
          type: src_app_services_rss_message_rss_message_service__WEBPACK_IMPORTED_MODULE_2__.RssMessageService
        }];
      };

      _ViewNewsPage = (0, tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-view-news',
        template: _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_view_news_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_view_news_page_scss__WEBPACK_IMPORTED_MODULE_1__]
      })], _ViewNewsPage);
      /***/
    },

    /***/
    13282:
    /*!*************************************************************************************************************************!*\
      !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/news/view-news/view-news.page.html ***!
      \*************************************************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n            <ion-back-button></ion-back-button>\n        </ion-buttons>\n        <ion-title>Actualités</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card>\n        <ion-card-header>\n            <ion-card-title>{{ item.title }}</ion-card-title>\n            <ion-card-subtitle>Par {{ item.author }} le {{ item.pubdate | date:'dd/MM/yyyy' }}</ion-card-subtitle>\n        </ion-card-header>\n\n        <ion-card-content>\n            <div [innerHtml]=\"item.description\"></div>\n            <ion-button href=\"{{ item.link }}\" slot=\"end\">Lire sur Netophonix</ion-button>\n        </ion-card-content>\n    </ion-card>\n</ion-content>";
      /***/
    },

    /***/
    50282:
    /*!**********************************************************!*\
      !*** ./src/app/pages/news/view-news/view-news.page.scss ***!
      \**********************************************************/

    /***/
    function _(module) {
      module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2aWV3LW5ld3MucGFnZS5zY3NzIn0= */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_pages_news_view-news_view-news_module_ts-es5.js.map