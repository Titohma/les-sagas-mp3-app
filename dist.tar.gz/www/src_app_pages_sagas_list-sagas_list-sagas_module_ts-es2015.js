"use strict";
(self["webpackChunkles_sagas_mp3"] = self["webpackChunkles_sagas_mp3"] || []).push([["src_app_pages_sagas_list-sagas_list-sagas_module_ts"],{

/***/ 50258:
/*!*********************************************************************!*\
  !*** ./src/app/pages/sagas/list-sagas/list-sagas-routing.module.ts ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListSagasPageRoutingModule": function() { return /* binding */ ListSagasPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _list_sagas_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-sagas.page */ 37694);




const routes = [
    {
        path: '',
        component: _list_sagas_page__WEBPACK_IMPORTED_MODULE_0__.ListSagasPage
    }
];
let ListSagasPageRoutingModule = class ListSagasPageRoutingModule {
};
ListSagasPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ListSagasPageRoutingModule);



/***/ }),

/***/ 56491:
/*!*************************************************************!*\
  !*** ./src/app/pages/sagas/list-sagas/list-sagas.module.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListSagasPageModule": function() { return /* binding */ ListSagasPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 7602);
/* harmony import */ var _list_sagas_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-sagas-routing.module */ 50258);
/* harmony import */ var _list_sagas_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-sagas.page */ 37694);







let ListSagasPageModule = class ListSagasPageModule {
};
ListSagasPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _list_sagas_routing_module__WEBPACK_IMPORTED_MODULE_0__.ListSagasPageRoutingModule
        ],
        declarations: [_list_sagas_page__WEBPACK_IMPORTED_MODULE_1__.ListSagasPage]
    })
], ListSagasPageModule);



/***/ }),

/***/ 37694:
/*!***********************************************************!*\
  !*** ./src/app/pages/sagas/list-sagas/list-sagas.page.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListSagasPage": function() { return /* binding */ ListSagasPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_list_sagas_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./list-sagas.page.html */ 58868);
/* harmony import */ var _list_sagas_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-sagas.page.scss */ 82826);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 7602);
/* harmony import */ var src_app_services_sagas_saga_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/sagas/saga.service */ 24041);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 42720);
/* harmony import */ var src_app_services_categories_category_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/categories/category.service */ 16471);
/* harmony import */ var src_app_entities_category__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/entities/category */ 15361);
/* harmony import */ var src_app_entities_saga__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/entities/saga */ 40373);










let ListSagasPage = class ListSagasPage {
    constructor(loadingController, categoryService, sagaService) {
        this.loadingController = loadingController;
        this.categoryService = categoryService;
        this.sagaService = sagaService;
        this.categories = [];
        this.items = [];
        this.isSearchRunning = false;
        this.numPage = 0;
        this.sizePage = 30;
    }
    ngOnInit() {
        this.loadingController.create({
            message: 'Téléchargement...'
        }).then((loading) => {
            loading.present();
            let categoriesRequest = this.categoryService.getAll();
            let authorsRequest = this.sagaService.getPaginated(this.numPage, this.sizePage);
            (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.forkJoin)([categoriesRequest, authorsRequest]).subscribe(results => {
                this.items = src_app_entities_saga__WEBPACK_IMPORTED_MODULE_5__.Saga.fromModels(results[1].content);
                this.categories = src_app_entities_category__WEBPACK_IMPORTED_MODULE_4__.Category.fromModels(results[0]);
                this.items = this.saveCategories(this.items);
                loading.dismiss();
            });
        });
    }
    search(searchInput) {
        if (searchInput.length > 2) {
            this.isSearchRunning = true;
            this.sagaService.search(searchInput)
                .subscribe(res => {
                this.items = src_app_entities_saga__WEBPACK_IMPORTED_MODULE_5__.Saga.fromModels(res);
                this.items = this.saveCategories(this.items);
            });
        }
    }
    cancelSearch() {
        this.isSearchRunning = false;
        this.sagaService.getPaginated(this.numPage, this.sizePage)
            .subscribe(res => {
            this.items = src_app_entities_saga__WEBPACK_IMPORTED_MODULE_5__.Saga.fromModels(res.content);
            this.items = this.saveCategories(this.items);
        });
    }
    loadData(event) {
        this.numPage++;
        this.sagaService.getPaginated(this.numPage, this.sizePage)
            .subscribe(res => {
            var sagas = src_app_entities_saga__WEBPACK_IMPORTED_MODULE_5__.Saga.fromModels(res.content);
            sagas = this.saveCategories(sagas);
            sagas.forEach(saga => this.items.push(saga));
            event.target.complete();
            if (this.numPage == res.totalPages) {
                event.target.disabled = true;
            }
        });
    }
    saveCategories(items) {
        items.forEach(item => {
            item.categories = [];
            item.categoriesRef.forEach(categoryRef => {
                item.categories.push(this.categories.find(result => result.id === categoryRef));
            });
        });
        return items;
    }
};
ListSagasPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController },
    { type: src_app_services_categories_category_service__WEBPACK_IMPORTED_MODULE_3__.CategoryService },
    { type: src_app_services_sagas_saga_service__WEBPACK_IMPORTED_MODULE_2__.SagaService }
];
ListSagasPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-list-sagas',
        template: _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_list_sagas_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_list_sagas_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ListSagasPage);



/***/ }),

/***/ 58868:
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/sagas/list-sagas/list-sagas.page.html ***!
  \****************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\r\n    <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n            <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>Liste des Sagas</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-toolbar>\r\n    <ion-searchbar showCancelButton=\"focus\" placeholder=\"Chercher une saga\" (ionChange)=\"search($event.target.value)\" (ionCancel)=\"cancelSearch()\"></ion-searchbar>\r\n</ion-toolbar>\r\n\r\n<ion-content>\r\n    <ion-list>\r\n        <ion-item *ngFor=\"let saga of items\" routerLink=\"/sagas/{{ saga.id }}\" routerDirection=\"forward\">\r\n            <ion-label>\r\n                <h2>{{ saga.title }}</h2>\r\n                <h3>\r\n                    <ion-badge *ngFor=\"let category of saga.categories\" class=\"categoryBadge\" color=\"medium\">\r\n                        {{ category.name }}\r\n                    </ion-badge>\r\n                </h3>\r\n            </ion-label>\r\n        </ion-item>\r\n    </ion-list>\r\n\r\n    <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\" [disabled]=\"isSearchRunning\">\r\n        <ion-infinite-scroll-content loadingText=\"Chargement...\">\r\n        </ion-infinite-scroll-content>\r\n    </ion-infinite-scroll>\r\n</ion-content>");

/***/ }),

/***/ 82826:
/*!*************************************************************!*\
  !*** ./src/app/pages/sagas/list-sagas/list-sagas.page.scss ***!
  \*************************************************************/
/***/ (function(module) {

module.exports = ".categoryBadge {\n  margin-right: 0.2em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpc3Qtc2FnYXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7QUFDSiIsImZpbGUiOiJsaXN0LXNhZ2FzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYXRlZ29yeUJhZGdlIHtcclxuICAgIG1hcmdpbi1yaWdodDogLjJlbTtcclxufSJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_sagas_list-sagas_list-sagas_module_ts-es2015.js.map