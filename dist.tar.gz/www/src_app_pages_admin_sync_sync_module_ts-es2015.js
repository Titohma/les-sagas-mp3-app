"use strict";
(self["webpackChunkles_sagas_mp3"] = self["webpackChunkles_sagas_mp3"] || []).push([["src_app_pages_admin_sync_sync_module_ts"],{

/***/ 12042:
/*!******************************************!*\
  !*** ./src/app/models/eventlog.model.ts ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventLogModel": function() { return /* binding */ EventLogModel; }
/* harmony export */ });
/* harmony import */ var _audit_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./audit.model */ 3809);

class EventLogModel extends _audit_model__WEBPACK_IMPORTED_MODULE_0__.AuditModel {
}


/***/ }),

/***/ 73321:
/*!*********************************************************!*\
  !*** ./src/app/pages/admin/sync/sync-routing.module.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SyncPageRoutingModule": function() { return /* binding */ SyncPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _sync_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sync.page */ 36104);




const routes = [
    {
        path: '',
        component: _sync_page__WEBPACK_IMPORTED_MODULE_0__.SyncPage
    }
];
let SyncPageRoutingModule = class SyncPageRoutingModule {
};
SyncPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SyncPageRoutingModule);



/***/ }),

/***/ 26714:
/*!*************************************************!*\
  !*** ./src/app/pages/admin/sync/sync.module.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SyncPageModule": function() { return /* binding */ SyncPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 7602);
/* harmony import */ var _sync_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sync-routing.module */ 73321);
/* harmony import */ var _sync_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sync.page */ 36104);







let SyncPageModule = class SyncPageModule {
};
SyncPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _sync_routing_module__WEBPACK_IMPORTED_MODULE_0__.SyncPageRoutingModule
        ],
        declarations: [_sync_page__WEBPACK_IMPORTED_MODULE_1__.SyncPage]
    })
], SyncPageModule);



/***/ }),

/***/ 36104:
/*!***********************************************!*\
  !*** ./src/app/pages/admin/sync/sync.page.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SyncPage": function() { return /* binding */ SyncPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_sync_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./sync.page.html */ 52693);
/* harmony import */ var _sync_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sync.page.scss */ 69535);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 7602);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 42720);
/* harmony import */ var src_app_models_eventlog_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/models/eventlog.model */ 12042);
/* harmony import */ var src_app_services_eventlog_eventlog_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/eventlog/eventlog.service */ 79159);
/* harmony import */ var src_app_services_sync_sync_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/sync/sync.service */ 74217);









let SyncPage = class SyncPage {
    constructor(loadingController, eventLogService, syncService) {
        this.loadingController = loadingController;
        this.eventLogService = eventLogService;
        this.syncService = syncService;
        this.lastSyncNews = new src_app_models_eventlog_model__WEBPACK_IMPORTED_MODULE_2__.EventLogModel();
        this.lastSyncSagas = new src_app_models_eventlog_model__WEBPACK_IMPORTED_MODULE_2__.EventLogModel();
    }
    ngOnInit() {
        this.loadingController.create({
            message: 'Téléchargement...'
        }).then((loading) => {
            loading.present();
            let syncNewsRequest = this.eventLogService.getLatestByName("SYNC_NEWS_START");
            let syncSagasRequest = this.eventLogService.getLatestByName("SYNC_SAGAS_START");
            (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.forkJoin)([syncNewsRequest, syncSagasRequest]).subscribe(results => {
                this.lastSyncNews = results[0];
                this.lastSyncSagas = results[1];
                loading.dismiss();
            }, error => {
                loading.dismiss();
            });
        });
    }
    doRefresh(event) {
        let syncNewsRequest = this.eventLogService.getLatestByName("SYNC_NEWS_START");
        let syncSagasRequest = this.eventLogService.getLatestByName("SYNC_SAGAS_START");
        (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.forkJoin)([syncNewsRequest, syncSagasRequest]).subscribe(results => {
            this.lastSyncNews = results[0];
            this.lastSyncSagas = results[1];
            event.target.complete();
        }, error => {
            event.target.complete();
        });
    }
    syncNews() {
        this.syncService.syncNews()
            .subscribe(res => { });
    }
    syncSagas() {
        this.syncService.syncSagas()
            .subscribe(res => { });
    }
};
SyncPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: src_app_services_eventlog_eventlog_service__WEBPACK_IMPORTED_MODULE_3__.EventLogService },
    { type: src_app_services_sync_sync_service__WEBPACK_IMPORTED_MODULE_4__.SyncService }
];
SyncPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-sync',
        template: _D_Dev_Workspace_les_sagas_mp3_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_sync_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_sync_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], SyncPage);



/***/ }),

/***/ 79159:
/*!*******************************************************!*\
  !*** ./src/app/services/eventlog/eventlog.service.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventLogService": function() { return /* binding */ EventLogService; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _config_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../config/config.service */ 88939);




let EventLogService = class EventLogService {
    constructor(http, configService) {
        this.http = http;
        this.configService = configService;
    }
    getLatestByName(name) {
        const params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams()
            .set('name', name);
        return this.http.get(`${this.configService.get('apiUrl')}/eventlogs`, { params });
    }
};
EventLogService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient },
    { type: _config_config_service__WEBPACK_IMPORTED_MODULE_0__.ConfigService }
];
EventLogService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], EventLogService);



/***/ }),

/***/ 74217:
/*!***********************************************!*\
  !*** ./src/app/services/sync/sync.service.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SyncService": function() { return /* binding */ SyncService; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _config_config_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../config/config.service */ 88939);




let SyncService = class SyncService {
    constructor(http, configService) {
        this.http = http;
        this.configService = configService;
    }
    syncNews() {
        return this.http.post(`${this.configService.get('apiUrl')}/sync/news`, {});
    }
    syncSagas() {
        return this.http.post(`${this.configService.get('apiUrl')}/sync/sagas`, {});
    }
};
SyncService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient },
    { type: _config_config_service__WEBPACK_IMPORTED_MODULE_0__.ConfigService }
];
SyncService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], SyncService);



/***/ }),

/***/ 52693:
/*!****************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/admin/sync/sync.page.html ***!
  \****************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\r\n    <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n            <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>Synchronisation</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n\r\n    <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\r\n        <ion-refresher-content></ion-refresher-content>\r\n    </ion-refresher>\r\n    <ion-list>\r\n        <ion-item-divider>\r\n            <ion-label>\r\n                Actualités\r\n            </ion-label>\r\n        </ion-item-divider>\r\n        <ion-item lines=\"none\">\r\n            Dernière exécution\r\n            <span slot=\"end\">{{ lastSyncNews.createdAt | date:'d/MM/yy HH:mm':'fr' }}</span>\r\n        </ion-item>\r\n        <ion-item>\r\n            <ion-button expand=\"block\" style=\"width: 100%\" (click)=\"syncNews()\">\r\n                <ion-icon slot=\"start\" name=\"paper-plane\"></ion-icon>\r\n                Lancer maintenant\r\n            </ion-button>\r\n        </ion-item>\r\n        <ion-item-divider>\r\n            <ion-label>\r\n                Liste des sagas\r\n            </ion-label>\r\n        </ion-item-divider>\r\n        <ion-item lines=\"none\">\r\n            Dernière exécution\r\n            <span slot=\"end\">{{ lastSyncSagas.createdAt | date:'d/MM/yy HH:mm':'fr' }}</span>\r\n        </ion-item>\r\n        <ion-item>\r\n            <ion-button expand=\"block\" style=\"width: 100%\" (click)=\"syncSagas()\">\r\n                <ion-icon slot=\"start\" name=\"paper-plane\"></ion-icon>\r\n                Lancer maintenant\r\n            </ion-button>\r\n        </ion-item>\r\n    </ion-list>\r\n</ion-content>");

/***/ }),

/***/ 69535:
/*!*************************************************!*\
  !*** ./src/app/pages/admin/sync/sync.page.scss ***!
  \*************************************************/
/***/ (function(module) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzeW5jLnBhZ2Uuc2NzcyJ9 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_admin_sync_sync_module_ts-es2015.js.map